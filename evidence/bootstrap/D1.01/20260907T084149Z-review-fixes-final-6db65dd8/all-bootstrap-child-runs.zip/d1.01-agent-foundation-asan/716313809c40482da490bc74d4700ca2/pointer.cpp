#include <ock/foundation/foundation.hpp>
using namespace ock::foundation;
inline constexpr ErrorDomain domain{"static"}; auto code=ErrorCode(&domain,3);
