#include <ock/foundation/foundation.hpp>
using namespace ock::foundation;
inline constexpr ErrorDomain domain{"static"}; constexpr auto code=ErrorCode::make<domain>(3); static_assert(code.value()==3);
