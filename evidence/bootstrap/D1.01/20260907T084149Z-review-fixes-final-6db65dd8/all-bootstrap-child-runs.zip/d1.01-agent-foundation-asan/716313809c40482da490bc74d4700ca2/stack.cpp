#include <ock/foundation/foundation.hpp>
using namespace ock::foundation;
void test(){ErrorDomain domain{"stack"}; auto code=ErrorCode::make<domain>(3);}
