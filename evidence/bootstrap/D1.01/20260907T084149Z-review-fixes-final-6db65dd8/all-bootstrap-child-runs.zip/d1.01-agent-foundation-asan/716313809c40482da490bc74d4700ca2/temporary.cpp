#include <ock/foundation/foundation.hpp>
using namespace ock::foundation;
auto code=ErrorCode::make<ErrorDomain{"temporary"}>(3);
