"""D0.02 静态依赖、公开表面和入口合同守卫；不执行产品授权。"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[2]

def load_manifest():
    return json.loads((ROOT/'sdk/sdk_api_manifest.json').read_text(encoding='utf-8'))

def normative_graph():
    text=(ROOT/'docs/01_Architecture_v3.3.md').read_text(encoding='utf-8')
    text=text.split('### A02.1',1)[1].split('### A02.2',1)[0]
    return {name:[] if deps.strip()=='无' else deps.strip().split('、')
            for name,deps in re.findall(r'^\| `OCK::([^`]+)` \| ([^|]+) \|',text,re.M)}

def transitive_dependencies(component,targets):
    seen=set();pending=list(targets[component]['dependencies'])
    while pending:
        name=pending.pop()
        if name in seen:continue
        seen.add(name)
        if name in targets:pending.extend(targets[name]['dependencies'])
    return seen

def validate_include(component,source,manifest,public=False):
    errors=[];targets=manifest['targets']
    allowed=transitive_dependencies(component,targets)|{component}
    # C/C++ 预处理先拼接续行，再将注释替换为空白；宏形式不能静默放行。
    text=re.sub(r'\\\r?\n','',source)
    text=re.sub(r'/\*.*?\*/|//[^\n]*',' ',text,flags=re.S)
    for directive in re.findall(r'^\s*#\s*include\b([^\n]*)',text,re.M):
        parsed=re.fullmatch(r'\s*(?:<([^>\n]+)>|"([^"\n]+)")\s*',directive)
        if not parsed:
            errors.append('无法解析的 include 需要显式审查：'+directive);continue
        include=parsed.group(1) or parsed.group(2)
        normalized=include.replace('\\','/')
        if '..' in normalized.split('/'):
            errors.append(f'包含路径不可跨目录逃逸：{include}');continue
        if normalized.startswith('ock/'):
            owners=[name for name,t in targets.items() if normalized.startswith(t['namespace_prefix'])]
            if not owners:errors.append(f'未知公开头所属组件：{include}');continue
            owner=max(owners,key=lambda name:len(targets[name]['namespace_prefix']))
            if owner not in allowed:errors.append(f'{component} 越层包含 {owner}: {include}')
            if '/detail/' in normalized or '/internal/' in normalized:
                if public or owner!=component:errors.append(f'私有头泄漏：{include}')
        elif public and any(normalized.startswith(prefix) for prefix in manifest['private_third_party_prefixes']):
            errors.append(f'第三方实现泄漏到公开头：{include}')
        elif '..' in normalized.split('/'):
            errors.append(f'包含路径不可跨目录逃逸：{include}')
    return errors

def validate_frontend_access(owner,kind,route,authorized,immutable):
    if owner not in ('UI','Workspace') or kind not in ('Read','StateEdit','ExternalEffect','Lifecycle'):
        return ['未知前端或业务形态']
    if route=='Operation':return []
    if route=='Direct' and kind=='Read' and authorized and immutable:return []
    return ['业务写必须经 Operation；直接读取仅限已授权不可变快照']

def validate_rpc_methods(methods):
    return [f'禁止通用状态 RPC：{method}' for method in methods if method.startswith('state.')]

def validate_manifest(manifest,actual_graph=None):
    errors=[]
    def require(value,message):
        if not value:errors.append(message)
    targets=manifest['targets'];norm=normative_graph()
    require(manifest['format']=='ock.sdk-api/1','公开清单格式不符')
    require(manifest['sdk_version']=='0.1.0-dev.1','开发 SDK 版本必须独立于文档 v3.3')
    require(manifest['stage']=='ContractBaseline','D0.02 仅为合同基线')
    require(set(targets)==set(norm),'产品 target 集合与 A02 不一致')
    for name,target in targets.items():
        require(target['dependencies']==norm.get(name),f'{name} 直接依赖与 A02 不一致')
        closure=transitive_dependencies(name,targets)
        require(name not in closure,f'{name} 依赖成环')
        require(set(target['dependencies'])<=targets.keys(),f'{name} 存在未知/测试目标依赖')
        require(target['export']=='OCK::'+name,f'{name} 导出名错误')
        require(target['kind']=='INTERFACE_LIBRARY',f'{name} 基线 target 类型错误')
        require(target['implementation']=='ContractBaseline',f'{name} 不得伪称已实现')
        require(target['public_compile_features']==['cxx_std_20'],f'{name} 公开编译条件漂移')
        require(target['public_compile_options']==['$<$<CXX_COMPILER_ID:MSVC>:/utf-8>'],f'{name} 公开编码选项漂移')
        require(target['api_classification'] in ('experimental','stable','detail'),f'{name} 分类无效')
        if target['api_classification']=='stable':
            require(not any(targets[d]['api_classification']!='stable' for d in closure if d in targets),
                    f'{name} stable 依赖非 stable')
        if actual_graph is not None:
            require(actual_graph.get(name,{}).get('dependencies')==target['dependencies'],f'{name} 实际 CMake 依赖不符')
            require(actual_graph.get(name,{}).get('implementation')==target['implementation'],f'{name} 实际目标能力声明不符')
            require(actual_graph.get(name,{}).get('compile_features')==target['public_compile_features'],f'{name} 实际公开编译要求漂移')
            require(actual_graph.get(name,{}).get('compile_options')==target['public_compile_options'],f'{name} 实际公开选项漂移')
    if actual_graph is not None:require(set(actual_graph)==set(norm),'实际 CMake 目标集合漂移')
    if 'Runtime' in targets:
        require(transitive_dependencies('Runtime',targets)=={'CoreContracts','Foundation'},'Runtime 必须保持最小闭包')
    if 'ControlClient' in targets:
        require(not (transitive_dependencies('ControlClient',targets)&{'Runtime','Control','Workspace'}),'薄客户端不能依赖服务端')
    require(manifest['required_frontends']==['CLI','Plan','ClientSDK'],'首发必需前端不能扩展到 DSL/REPL')
    require(manifest['optional_frontends']==['DSL','REPL'],'DSL/REPL 必须保持可选')
    require(manifest['frozen_previous_release']['exists'] is False,'没有上一正式 SDK，不得伪造兼容结果')
    require(manifest['planned_executables']=={'ock':{'dependencies':['ControlClient','Adapter::LocalIPC'],'external_dependencies':['CLI11'],'owner_task':'D2.06','implementation':'Planned'}},'CLI 仅登记 D2.06 依赖，不能提前构建假 Host')
    listed=[]
    for header in manifest['headers']:
        path=ROOT/header['path'];listed.append(path.resolve())
        require(path.is_file(),f'公开头缺失：{path}')
        require(header['target'] in targets,'公开头所有者错误')
        require(header['classification']=='experimental','0.x 基线公开头尚未承诺 Stable')
        if path.is_file():
            require(hashlib.sha256(path.read_bytes()).hexdigest()==header['sha256'],f'公开头声明/字节变化需要审查：{path}')
            errors.extend(validate_include(header['target'],path.read_text(encoding='utf-8'),manifest,True))
    header_suffixes={'.h','.hpp','.hh','.hxx','.inl','.ipp'}
    installed={p.resolve() for p in (ROOT/'packages').rglob('*') if p.suffix in header_suffixes and 'include' in p.parts}
    require(set(listed)==installed and len(listed)==len(set(listed)),'公开头增加/删除/重复未登记')
    for candidate in manifest['candidate_headers']:
        require(candidate['target'] in targets and candidate['status']=='Planned','候选头状态不正确')
        require(not (ROOT/candidate['path']).exists(),'候选头已实现时必须转入受审查公开集合')
    for path in (ROOT/'packages').rglob('*'):
        if path.suffix not in header_suffixes|{'.cpp','.cc','.cxx'}:continue
        relative=path.relative_to(ROOT).as_posix()
        owners=[name for name,t in targets.items() if relative.startswith(t['include_root'].split('/include')[0]+'/')]
        if not owners:errors.append(f'源码没有组件所有者：{relative}');continue
        owner=max(owners,key=lambda name:len(targets[name]['include_root']))
        errors.extend(validate_include(owner,path.read_text(encoding='utf-8'),manifest,'/include/' in relative))
    return errors

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--graph',type=Path)
    args=parser.parse_args()
    try:
        graph=None if args.graph is None else json.loads(args.graph.read_text(encoding='utf-8'))['targets']
        manifest=load_manifest();errors=validate_manifest(manifest,graph)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        errors=[str(exc)]
    print(json.dumps({'check_id':'CHECK.D0.02.architecture','errors':errors,'scope':'合同目标/公开表面静态检查；无Runtime运行或授权实现'},ensure_ascii=False,indent=2))
    return bool(errors)

if __name__=='__main__':sys.exit(main())
