#include "test_support.hpp"
void test(ReadServices<Reader>& services){services.reader().value=9;}
