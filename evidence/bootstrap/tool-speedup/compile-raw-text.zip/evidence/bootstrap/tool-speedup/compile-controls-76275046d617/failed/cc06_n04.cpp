#include "test_support.hpp"
void test(WorkContext& context){context.sql();}
