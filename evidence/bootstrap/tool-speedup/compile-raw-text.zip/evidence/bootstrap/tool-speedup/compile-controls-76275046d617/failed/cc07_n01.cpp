#include "test_support.hpp"
Result<int> adapter(const Other&,const Provider::CandidateReadPort&,WorkContext&);void test(const OperationDefinition<int,int>& d){auto rejected=with_candidate_read<Provider>(d,adapter,name("provider"));}
