#include "test_support.hpp"
struct Bad{}; namespace ock::contracts {template<>struct TypeContract<Bad>{static TypeIdentity identity(){return TypeContract<int>::identity();}static bool validate(const Bad&){return true;}};} Result<int> f(const Bad&,WorkContext&);auto rejected=make_compute_definition(f,input(AtomicMode::PureCompute));
