#include "test_support.hpp"
auto rejected=make_state_edit_definition<int,int,OtherProvider>(edit_handler,input(AtomicMode::StateEdit));
