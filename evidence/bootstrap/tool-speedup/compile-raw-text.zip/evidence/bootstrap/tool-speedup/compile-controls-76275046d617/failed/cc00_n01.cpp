#include "test_support.hpp"
Result<double> f(const double&,WorkContext&); auto rejected=make_compute_definition(f,input(AtomicMode::PureCompute));
