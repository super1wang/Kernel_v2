#include "test_support.hpp"
void test(const BoundOperation<Borrowed,int>& b,Borrowed a){auto rejected=prepare_submit_args(b,std::move(a));}
