#include "test_support.hpp"
void test(EditView<Provider>& view){view.commit();}
