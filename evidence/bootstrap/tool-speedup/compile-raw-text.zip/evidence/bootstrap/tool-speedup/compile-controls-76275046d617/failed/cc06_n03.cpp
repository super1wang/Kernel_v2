#include "test_support.hpp"
void test(WorkContext& context){context.get_service<Reader>();}
