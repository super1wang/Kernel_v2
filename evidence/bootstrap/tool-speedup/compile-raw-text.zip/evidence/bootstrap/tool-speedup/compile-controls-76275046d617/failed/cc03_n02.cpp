#include "test_support.hpp"
auto rejected=make_state_edit_definition(compute_handler,input(AtomicMode::StateEdit));
