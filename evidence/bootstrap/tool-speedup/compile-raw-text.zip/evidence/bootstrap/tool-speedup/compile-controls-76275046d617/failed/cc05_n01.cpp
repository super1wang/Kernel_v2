#include "test_support.hpp"
Result<int> f(const int&,TransitionView&);auto rejected=make_lifecycle_definition(f,input());
