#include "test_support.hpp"
void test(const BoundOperation<int,int>& b){b.handler();}
