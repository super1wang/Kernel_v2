#include "test_support.hpp"
auto rejected=make_compute_definition<Other,Other>(compute_handler,input(AtomicMode::PureCompute));
