#include "test_support.hpp"
Result<int> f(const int&,EffectContext&);auto rejected=make_effect_definition(f,input());
