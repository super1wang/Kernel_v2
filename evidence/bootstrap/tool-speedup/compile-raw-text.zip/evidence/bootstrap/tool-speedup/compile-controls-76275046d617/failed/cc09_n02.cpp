#include "test_support.hpp"
void test(DefinitionSnapshot& a,const DefinitionSnapshot& b){a=b;}
