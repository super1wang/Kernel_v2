#include "test_support.hpp"
auto forged=CppTypeToken(static_cast<const unsigned char*>(nullptr));
