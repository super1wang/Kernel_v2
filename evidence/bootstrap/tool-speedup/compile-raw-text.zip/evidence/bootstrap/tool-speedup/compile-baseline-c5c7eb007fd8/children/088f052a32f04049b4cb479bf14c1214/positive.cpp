#include "test_support.hpp"
auto accepted=make_compute_definition(compute_handler,input(AtomicMode::PureCompute));
