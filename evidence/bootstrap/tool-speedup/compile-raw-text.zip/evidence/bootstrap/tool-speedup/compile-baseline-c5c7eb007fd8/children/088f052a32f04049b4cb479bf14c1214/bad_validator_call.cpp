#include "test_support.hpp"
void f(const BoundOperation<int,int>& b){auto rejected=validate_inline_args(b,Other{1});}
