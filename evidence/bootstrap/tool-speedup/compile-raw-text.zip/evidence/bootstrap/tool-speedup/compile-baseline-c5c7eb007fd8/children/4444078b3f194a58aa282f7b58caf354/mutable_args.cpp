#include "test_support.hpp"
Result<int> f(int&,WorkContext&);auto rejected=make_compute_definition(f,input(AtomicMode::PureCompute));
