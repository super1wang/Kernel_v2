"""本批次变更的三个真实安装边界与冷描述结构；复用已建runner，新证据目录。"""
from pathlib import Path
import json,re,sys,uuid
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from tools.evidence.process import execute
from tools.evidence.common import save_json,sha_file
out=ROOT/'evidence/bootstrap/D1.06'/('sdk-boundaries-'+uuid.uuid4().hex[:10]);out.mkdir()
build=ROOT/'build/d1.06-sdk-7aef73cd8f'
rows=[]
for folder,stem,case in [('registration','registration','T24.registration.internal_component_boundary'),('registration','registration','T24.registration.cold_docs_separation'),('authorization','policy','T20.policy.internal_component_boundary'),('native','native','T03.native.component_boundary')]:
 discovery=build/'tests/contract'/folder/(stem+'-tests-Debug.cmake')
 line=next(x for x in discovery.read_text(encoding='utf-8').splitlines() if x.startswith('add_test(') and ('[==['+case+']==]') in x)
 args=re.findall(r'\[==\[(.*?)\]==\]',line)
 args=args[args.index('--case'):]
 args[args.index('--work')+1]=str(out/folder)
 script=ROOT/'tests/contract'/folder/'verify_children.py'
 raw=[out/(str(len(rows))+'-'+s+'.log') for s in ('stdout','stderr')]
 row=execute([sys.executable,'-X','utf8',str(script),*args],ROOT,*raw,600)
 row.update(source_sha256=sha_file(script),raw=[{'path':x.name,'sha256':sha_file(x),'size':x.stat().st_size} for x in raw])
 rows.append(row);save_json(out/'commands.json',rows)
 tree=row['process_tree']
 if row['status']!='Exited' or row['exit_code']!=0 or tree['active_after'] or tree['terminated_owned_job'] or not tree['assigned_before_resume']:
  raise ValueError('changed boundary failed: '+case)
print(out)
