"""SDK有限交付索引：保留原目录，仅归档源码/原始流/命令/实际文本轨迹。"""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'evidence/bootstrap/D1.06'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,data):path.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))


def main():
    owned=json.loads((BASE/'sdk-owned-files.json').read_text(encoding='utf-8'))
    source=[{'path':name,'sha256':sha(ROOT/name),'size':(ROOT/name).stat().st_size} for name in sorted(owned)]
    manifest=json.loads((ROOT/'sdk/sdk_api_manifest.json').read_text(encoding='utf-8'))
    dependencies=[{'path':h['path'],'sha256':sha(ROOT/h['path'])} for h in manifest['headers'] if h['path'] not in owned]
    digest=hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    save(BASE/'sdk-source-identity.json',{'scope':'本子任务源码字节；共享Host/Logging完整实现另由负责人冻结',
         'sha256':digest,'owned':source,'shared_installed_headers':dependencies})
    stages={'sdk-stage-60224d5e7f','sdk-stage-e96c22e3ee','sdk-stage-7aef73cd8f',
            'sdk-stage-4dcee1ee3b','sdk-stage-c8ebabb534','sdk-stage-0d5a4652ab',
            'sdk-stage-c7bae4df64'}
    directories=[p for p in BASE.glob('sdk-*') if p.is_dir() and (not p.name.startswith('sdk-stage-') or p.name in stages)]
    suffixes={'.log','.json','.xml','.cmake','.txt','.cpp','.hpp','.h','.py','.vcxproj','.props','.targets','.tlog'}
    excluded={'CMakeCache.txt','cmake.check_cache','generate.stamp','generate.stamp.depend','generate.stamp.list','TargetDirectories.txt'}
    material={ROOT/name for name in owned}
    material.update(ROOT/h['path'] for h in manifest['headers'])
    material.update(ROOT/'docs'/name for name in ('01_Architecture_v3.3.md','02_Execution_Plan_v3.3.md'))
    for directory in directories:
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix.lower() in suffixes and path.name not in excluded and '__pycache__' not in path.parts:
                material.add(path)
    results=[]
    for directory in directories:
        result=directory/'result.json'
        profile=directory/'profile.json'
        if result.is_file():
            results.append({'path':str(result.relative_to(ROOT)),'sha256':sha(result),
                            'value':json.loads(result.read_text(encoding='utf-8'))})
        if profile.is_file():
            data=json.loads(profile.read_text(encoding='utf-8'))
            producer=Path(data['producer'])
            for path in [producer/'CMakeCache.txt',producer/'ock-target-graph.json',producer/'ock_Runtime.vcxproj']:
                if path.is_file():material.add(path)
            material.update((producer/'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'))
            material.update((producer/'ock_Runtime.dir').glob('*/*.tlog/CL.command.1.tlog'))
            material.update((producer/'ock_Runtime.dir').glob('*/*.tlog/Lib.command.1.tlog'))
    current=[x for x in results if x['value'].get('case')=='installed_host' and
             json.loads((ROOT/x['path']).with_name('profile.json').read_text(encoding='utf-8')).get('producer','').endswith('d1.06-sdk-0d5a4652ab')]
    if len(current)!=1 or current[0]['value'].get('status')!='Passed':raise ValueError('current LF Debug installed consumer missing')
    latest=(ROOT/current[0]['path']).parent
    save(BASE/'sdk-summary.json',{'scope':'开发集成与SDK职责，非D1.06/G1包验收','source_digest':digest,
        'current_debug':{'source':'evidence/bootstrap/D1.06/sdk-stage-0d5a4652ab/source',
                         'inputs_sha256':sha(BASE/'sdk-stage-0d5a4652ab/inputs.json'),
                         'prefix':str(latest/'relocated-prefix'),'result':current[0]},
        'development_results':results,'unrun':'正式最终来源的D1.06 S_required/G1和footprint预算',
        'archive_policy':'不删除原目录；不收obj/PDB/重复二进制；实际二进制见原artifacts.json和原路径'})
    material.update(BASE/name for name in ('sdk-source-identity.json','sdk-summary.json','sdk-self-review.md',
                                          'sdk-owned-files.json','sdk-evidence-index.py','sdk-boundary-check.py'))
    archive=BASE/'sdk-raw-text.zip';members=[]
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
        for path in sorted(material):
            name=path.relative_to(ROOT).as_posix();raw=path.read_bytes()
            bundle.writestr(name,raw)
            members.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)})
    with zipfile.ZipFile(archive) as bundle:
        if len(bundle.namelist())!=len(members):raise ValueError('duplicate archive member')
        for row in members:
            raw=bundle.read(row['path'])
            if len(raw)!=row['size'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ValueError('archive readback mismatch')
    save(BASE/'sdk-archive-index.json',{'archive':archive.name,'sha256':sha(archive),'size':archive.stat().st_size,
                                     'source_digest':digest,'members':members})
    print(json.dumps({'source_digest':digest,'members':len(members),'archive_size':archive.stat().st_size,
                      'archive_sha256':sha(archive),'prefix':str(latest/'relocated-prefix')},ensure_ascii=False))


if __name__=='__main__':main()
