"""把已手写职责选择物化为候选；只读固定历史expected，绝不调用discovery。"""
from pathlib import Path
import copy, hashlib, json, re
ROOT=Path(__file__).resolve().parents[3]
def read(name):return json.loads((ROOT/name).read_text(encoding='utf8'))
def write(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for name,want in [('d1.05','37fee8ea9da96b3a553714f49426c85dd88181de96c8df313df57cbb0ba699a1'),('d0.06','8d722002816a334931f8dd222f1c87d668e3d57c6e7b787d95f5a08b9e86de2d')]:
    if hashlib.sha256((ROOT/f'tests/manifests/{name}.expected.json').read_bytes()).hexdigest()!=want:raise ValueError('fixed source changed')
old=read('tests/manifests/d1.05.expected.json');d0=read('tests/manifests/d0.06.expected.json')
D='win-msvc-debug';R='win-msvc-release';A='win-msvc-asan';ALL=[D,R,A]
cases={}
def add(name,profiles=ALL):
    if name in cases:raise ValueError('duplicate hand-selected ID '+name)
    cases[name]={'id':name,'repeat_required':1,'profiles':list(profiles)}
for row in old['cases']:
    name=row['id']
    if any('.'+family+'.' in name for family in ('foundation','contracts','registration','policy','native')):
        debug_only=name.startswith(('T24.foundation.','T01.contracts.','T24.contracts.'))
        add(name,[D] if debug_only else ALL)
    elif name in ('T01.architecture.dependency_dag','T01.architecture.negative_guards','T24.sdk.install_and_missing_components') or '.conformance.' in name:add(name,[D])
    elif name in ('T24.sdk.version_header','T01.dependencies.expected','T01.dependencies.toolchain','T01.dependencies.lock_contracts'):add(name)
    elif name in ('T23.dependencies.asan_healthy','T23.dependencies.asan_detects_heap_overflow'):add(name,[A])
for row in d0['cases']:
    if row['id'].startswith(('T23.process.','T23.evidence.')):add(row['id'],[D])
add('T02.contracts.compile_fixture_setup');add('T02.contracts.compile_fixture_guards',[D])
host={
 'T03.host.':'configuration catalog_registration start_order start_failures ready_gate native_results session_ownership delegation_revoke',
 'T22.host.':'lifecycle_reentrancy shutdown_order shutdown_errors shutdown_deadline pending_report admission_race return_lifetime destructor_guard',
 'T19.host.':'logging_ownership','T23.host.':'allocation_controls steady_allocation owner_reclamation'}
for prefix,names in host.items():
    for name in names.split():add(prefix+name)
for backend in ('memory','test'):
    for name in 'accept_reject_drop_accounting format_redaction error_isolation flush_accepted_range shutdown_callback_lifetime'.split():add(f'T22.logging.{backend}.{name}')
add('T19.logging.memory_pages');add('T23.logging.fixed_write_allocation')
for name in 'metadata public_headers installed_host no_tests_producer link_closure install_pruning_rejected'.split():add('T24.native_sdk.'+name,[D] if name in ('metadata','install_pruning_rejected') else ALL)
add('T02.native_sdk.private_dispatch');add('T01.native_sdk.surface_guard',[D])
for name in 'method_identity module_accounting memory_calibration thread_clock_calibration phase_repetition owned_process raw_integrity budget_provenance'.split():add('T23.footprint.'+name,[D])
add('T23.footprint.native_occupancy');add('T23.footprint.allocation_report');add('T23.footprint.ready_latency',[R])
expected={'format':'ock.expected/1','task_id':'D1.06',
 'scope':'Candidate：按D1.06-formal-scope-candidate手写职责物化；footprint入口和预算未冻结，正式运行由专用preload拒绝；不继承历史Passed。',
 'cases':sorted(cases.values(),key=lambda x:x['id']),'checks':copy.deepcopy(old['checks'])}
write('tests/manifests/d1.06.expected.json',expected)
for suffix,profile,config in [('debug',D,'Debug'),('release',R,'Release'),('asan',A,'Debug')]:
    original=read(f'tests/runs/d1.05-win-msvc-{suffix}.json')
    spec=json.loads(json.dumps(original).replace('d1.05','d1.06').replace('D1.05','D1.06'))
    build=spec['build_dir'];root=build+'/tests/compile/contracts/child-runs'
    spec['configure'][1:1]=['-C','tests/runs/d1.06-prerequisites.cmake']
    spec['configure'] += ['-DOCK_BUILD_HOST_TESTS=ON','-DOCK_BUILD_LOGGING_TESTS=ON','-DOCK_BUILD_NATIVE_SDK_TESTS=ON']
    spec['source_patterns'] += ['examples/stateless_service/**','docs/plans/D1.06.md','docs/reviews/D1.06-formal-scope-candidate.md','footprint-budgets.json']
    spec['required_artifacts'] += ['tests/manifests/d1.06.expected.json','tests/runs/d1.06-prerequisites.cmake','tests/runs/d1.06-matrix.json','tests/runs/g1-native-matrix.json',
      'docs/contracts/native-host-api.md','docs/contracts/logging-api.md','docs/contracts/native-sdk-surface.md','docs/contracts/native-footprint-method.md','docs/contracts/native-test-scope.md',
      'tests/conformance/logging/cases.json','footprint-budgets.json']
    spec['source_patterns']=list(dict.fromkeys(spec['source_patterns']))
    spec['required_artifacts']=list(dict.fromkeys(spec['required_artifacts']))
    spec['build_outputs']=[x for x in spec['build_outputs'] if not x.endswith(('_registry_internal.lib','_policy_internal.lib','_invocation_internal.lib'))]
    spec['build_outputs'] += [f'{build}/{config}/ock_Runtime.lib',f'{build}/ock_Runtime.vcxproj',
      f'{build}/tests/contract/host/{config}/ock_host_tests.exe',f'{build}/tests/contract/host/{config}/ock_host_fault_tests.exe',
      f'{build}/tests/contract/host/CTestTestfile.cmake',f'{build}/tests/conformance/logging/{config}/ock_logging_tests.exe',
      f'{build}/tests/conformance/logging/CTestTestfile.cmake',f'{build}/tests/compile/contracts/compile-profile-{config}.txt']
    names=[x['id'] for x in expected['cases'] if profile in x['profiles']]
    spec['test_regex']='^('+'|'.join(re.escape(x) for x in names)+')$'
    # 原R/P/N包装最低工件保持原值；CompileContracts按已审同run共享夹具的新布局登记。
    rows=[]
    for item in spec['required_runtime_artifacts']:
        pattern=item['pattern']
        if 'tests/compile/contracts/child-runs/' in pattern:continue
        if suffix!='debug' and pattern.startswith(('build/d1.01-sdk/','build/d1.02-sdk/')):continue
        rows.append(item)
    def required(pattern,minimum=1):rows.append({'pattern':pattern,'minimum':minimum})
    required(root+'/*/commands.json',12);required(root+'/*/fixture-use.json',10)
    required(root+'/fixtures/*/ready.json');required(root+'/fixtures/*/CMakeLists.txt')
    required(root+f'/fixtures/*/build/*.dir/{config}/*.obj',10)
    spec['runtime_artifact_patterns'] += [root+'/fixtures/**/*',f'{build}/tests/contract/host/child-runs/**/*']
    required(f'{build}/tests/contract/host/child-runs/*/commands.json',5)
    required(f'{build}/tests/contract/host/child-runs/*/result.json',5)
    logging=f'{build}/tests/conformance/logging'
    spec['build_outputs'].append(logging+'/logging-binding.json')
    spec['runtime_artifact_patterns'].append(logging+'/child-runs/**/*')
    required(logging+'/child-runs/*/*/commands.json',12)
    required(logging+'/child-runs/*/*/result.json',12)
    required(logging+'/child-runs/*/qualification.json')
    sdk_cases=['public_headers','installed_host','no_tests_producer','link_closure','private_dispatch']
    if suffix=='debug':sdk_cases+=['metadata','install_pruning_rejected']
    for name in sdk_cases:
        where=f'evidence/bootstrap/D1.06/sdk-{name}-*'
        for pattern in ('**/*.json','**/*.log','**/*.cpp','**/*.hpp','**/*.cmake','**/CMakeLists.txt','**/*.tlog','**/*.exe'):
            spec['runtime_artifact_patterns'].append(where+'/'+pattern)
        required(where+'/commands.json');required(where+'/result.json');required(where+'/artifacts.json')
    # 最终入口尚缺：这些是必须交付的报告位置，不创建占位工件。
    modes=['native_occupancy','allocation_report']+(['ready_latency'] if suffix=='release' else [])
    for mode in modes:
        where=f'evidence/G1/{profile}/{mode}/*'
        spec['runtime_artifact_patterns'].append(where+'/**/*')
        required(where+'/report.json');required(where+'/commands.json');required(where+'/budget-binding.json')
    spec['required_runtime_artifacts']=rows
    # Python3.11 Path.glob('**')递归，而审计Path.match('**')只有一层；固定展开避免口径分叉。
    patterns=[]
    for pattern in spec['runtime_artifact_patterns']:
        if '**/' in pattern:
            patterns.extend(pattern.replace('**/','*/'*depth) for depth in range(13))
        else:patterns.append(pattern)
    spec['runtime_artifact_patterns']=list(dict.fromkeys(patterns))
    write(f'tests/runs/d1.06-win-msvc-{suffix}.json',spec)
matrix={'format':'ock.gate-matrix/1','gate_id':'D1.06','required_runs':[{'task_id':'D1.06','profile':p} for p in ALL]}
write('tests/runs/d1.06-matrix.json',matrix)
matrix['gate_id']='G1';write('tests/runs/g1-native-matrix.json',matrix)
print(json.dumps({profile:sum(profile in c['profiles'] for c in expected['cases']) for profile in ALL}))
