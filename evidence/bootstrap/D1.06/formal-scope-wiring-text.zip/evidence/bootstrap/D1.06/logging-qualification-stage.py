"""资格接线局部验证：冻结源码，只编真实Logging实现及同一测试目录，非完整Runtime验收。"""
from pathlib import Path
import hashlib,json,re,shutil,sys,uuid
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from tools.evidence.process import execute
from tools.evidence.common import save_json,sha_file,junit_cases

def main():
    tag=uuid.uuid4().hex[:10];out=ROOT/'evidence/bootstrap/D1.06'/('logging-qualification-'+tag)
    source=out/'source';source.mkdir(parents=True);build=ROOT/'build'/('d1.06-logqual-'+tag)
    inputs=[]
    folders=['packages/foundation/include','packages/contracts/include','packages/runtime/include',
      'packages/runtime/observability','tests/conformance/logging','tests/conformance/support','tools/evidence','tools/development','cmake']
    paths=set()
    for folder in folders:
        paths.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.update(ROOT/name for name in ['tests/contract/native/allocation_probe.cpp','tests/contract/native/allocation_probe.hpp',
      'cmake/LockedMSVC.cmake','dependencies.lock'])
    for path in sorted(paths):
        rel=path.relative_to(ROOT);dest=source/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
        inputs.append({'path':rel.as_posix(),'sha256':sha_file(dest)})
    save_json(out/'inputs.json',inputs)
    expected=ROOT/'build/d0.06-a/cache/sources/expected-fe3b18aecb84/include'
    cmake=f'''cmake_minimum_required(VERSION 3.25)
project(LoggingQualificationStage LANGUAGES CXX)
enable_testing()
find_package(Python3 REQUIRED COMPONENTS Interpreter)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")
set(CMAKE_INTERPROCEDURAL_OPTIMIZATION OFF)
add_library(stage_contracts INTERFACE)
add_library(OCK::CoreContracts ALIAS stage_contracts)
target_include_directories(stage_contracts INTERFACE "${{PROJECT_SOURCE_DIR}}/packages/foundation/include" "${{PROJECT_SOURCE_DIR}}/packages/contracts/include")
target_include_directories(stage_contracts SYSTEM INTERFACE "{expected.as_posix()}")
add_library(stage_logging STATIC packages/runtime/observability/logging.cpp)
add_library(OCK::Runtime ALIAS stage_logging)
target_link_libraries(stage_logging PUBLIC OCK::CoreContracts)
target_include_directories(stage_logging PUBLIC "${{PROJECT_SOURCE_DIR}}/packages/runtime/include")
target_compile_features(stage_logging PUBLIC cxx_std_20)
target_compile_options(stage_logging PRIVATE /utf-8 /EHsc /Zc:__cplusplus /permissive- /Zc:nrvo-)
add_subdirectory(tests/conformance/logging)
'''
    (source/'CMakeLists.txt').write_text(cmake,encoding='utf8')
    save_json(out/'external-inputs.json',[{'path':str(p),'sha256':sha_file(p)} for p in [Path(__file__),expected/'tl/expected.hpp',source/'CMakeLists.txt']])
    commands=[]
    def run(label,argv,expected_code=0):
        row=execute(argv,ROOT,out/(label+'-stdout.log'),out/(label+'-stderr.log'),600)
        row['raw']=[{'path':label+'-'+s+'.log','sha256':sha_file(out/(label+'-'+s+'.log')),'size':(out/(label+'-'+s+'.log')).stat().st_size} for s in ('stdout','stderr')]
        commands.append(row);save_json(out/'commands.json',commands)
        print(label,row['status'],row['exit_code'],str(out),flush=True)
        tree=row['process_tree']
        if not(row['status']=='Exited' and row['exit_code']==expected_code and row['observed_exit_code']==expected_code and tree['assigned_before_resume'] and tree['active_after']==0 and not tree['terminated_owned_job']):raise ValueError(label+' failed')
    run('units',[sys.executable,'-X','utf8','-m','unittest','tests.conformance.test_bootstrap','tests.conformance.logging.test_qualification','tests.tools.dev.test_d106_scope','tests.tools.dev.test_verify','-v'])
    run('blocked',['cmake','-P',str(ROOT/'tests/runs/d1.06-prerequisites.cmake')],1)
    if b'D1.06 formal candidate blocked' not in (out/'blocked-stderr.log').read_bytes():raise ValueError('wrong preload failure')
    run('configure',['cmake','-S',str(source),'-B',str(build),'-G','Visual Studio 17 2022','-A','x64','-T','v143,version=14.44.35207','-DCMAKE_SYSTEM_VERSION=10.0.26100.0','-DCMAKE_TOOLCHAIN_FILE='+str(source/'cmake/LockedMSVC.cmake')])
    run('build',['cmake','--build',str(build),'--config','Debug','--parallel','2','--','/nr:false'])
    run('ctest',['ctest','--test-dir',str(build),'-C','Debug','-R',r'^T(19|22|23)\.logging\.','--verbose','--output-junit',str(out/'junit.xml')])
    cases=junit_cases(out/'junit.xml')
    if len(cases)!=12 or any(c['status']!='Passed' for c in cases):raise ValueError('not actual 12 Passed')
    run_root=build/'tests/conformance/logging/child-runs'
    qualified=list(run_root.glob('*/qualification.json'))
    if len(qualified)!=1 or not json.loads(qualified[0].read_text())['qualified']:raise ValueError('no real qualification')
    save_json(out/'result.json',{'status':'Passed','scope':'局部Debug资格接线，不是完整Runtime/包验收','cases':cases,'qualification':str(qualified[0])})
    return 0

if __name__=='__main__':sys.exit(main())
