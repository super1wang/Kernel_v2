"""复用实际冻结12项，验证新CTest不能借旧轮补缺项；不重跑共同套件。"""
from pathlib import Path
import copy,json,sys,uuid
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from tools.evidence.common import save_json,sha_file
from tools.evidence.process import execute
from tests.conformance.logging.qualification import qualify,CASES

base=Path(sys.argv[1]).resolve();tag=uuid.uuid4().hex[:10]
out=ROOT/'evidence/bootstrap/D1.06'/('logging-qualification-controls-'+tag);out.mkdir()
build=ROOT/'build'/('d1.06-logqual-'+base.name.rsplit('-',1)[1])
work=build/'tests/conformance/logging';runs=work/'child-runs'
previous=list(runs.glob('*/qualification.json'))
if len(previous)!=1:raise ValueError('expected exactly one original real qualified run')
before={p.name for p in runs.iterdir()};original=previous[0];digest=sha_file(original)
records=[]
def run(label,argv,code):
    row=execute(argv,ROOT,out/(label+'-stdout.log'),out/(label+'-stderr.log'),120)
    row['raw']=[{'path':label+'-'+s+'.log','sha256':sha_file(out/(label+'-'+s+'.log')),'size':(out/(label+'-'+s+'.log')).stat().st_size} for s in ('stdout','stderr')]
    records.append(row);save_json(out/'commands.json',records)
    tree=row['process_tree']
    if not(row['status']=='Exited' and row['exit_code']==code and row['observed_exit_code']==code and tree['assigned_before_resume'] and tree['active_after']==0 and not tree['terminated_owned_job']):raise ValueError(label+' wrong actual exit/Job')
run('formal-guards',[sys.executable,'-X','utf8','-m','unittest','tests.tools.dev.test_formal_scope','-v'],0)
run('discovery',['ctest','--test-dir',str(build),'-C','Debug','-N'],0)
if before!={p.name for p in runs.iterdir()}:raise ValueError('-N created execution evidence')
run('missing-current-run',['ctest','--test-dir',str(build),'-C','Debug','-R','^T23[.]logging[.]fixed_write_allocation$','--verbose','--output-junit',str(out/'missing.xml')],8)
new={p.name for p in runs.iterdir()}-before
if len(new)!=1:raise ValueError('CTest did not create exactly one new execution run')
current=runs/next(iter(new))
row=json.loads((current/CASES[-1]/'result.json').read_text())
if row['status']!='Failed' or (current/'qualification.json').exists() or sha_file(original)!=digest:raise ValueError('old qualification leaked or changed')
actual=json.loads(original.read_text());binding=json.loads((work/'logging-binding.json').read_text())
rows=[json.loads((original.parent/c/'result.json').read_text()) for c in CASES]
rejections=[]
for field,value in [('run_id',current.name),('binary_sha256','0'*64),('binding_sha256','0'*64),('status','Failed')]:
    bad=copy.deepcopy(rows);bad[0][field]=value
    try:qualify(binding,bad,actual['run_id'],actual['binary_sha256'])
    except ValueError as error:rejections.append({'changed_field':field,'rejected':str(error)})
    else:raise ValueError('actual-record mutation incorrectly qualified')
save_json(out/'result.json',{'status':'Passed','scope':'限定守卫控制，真实缺项轮失败不是Logging行为失败',
  'base':str(base),'original_qualification_sha256':digest,'new_missing_run':str(current),'actual_record_rejections':rejections})
print(out)
