"""精选可提交材料；保留所有原目录，不收入 obj/编译缓存。"""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'evidence/bootstrap/D1.06'
names=['docs/reviews/D1.06-formal-scope-candidate.md','tests/manifests/d1.06.expected.json',
 'tests/runs/d1.06-matrix.json','tests/runs/g1-native-matrix.json','tests/runs/d1.06-prerequisites.cmake',
 *['tests/runs/d1.06-win-msvc-'+x+'.json' for x in ('debug','release','asan')],
 'tools/dev/verify.py','tests/tools/dev/test_verify.py','tests/tools/dev/test_d106_scope.py','tests/tools/dev/test_formal_scope.py',
 'tests/conformance/support/harness.py','tests/conformance/support/identity.py',
 *['tests/conformance/logging/'+x for x in ('CMakeLists.txt','logging-tests.cmake.in','logging_tests.cpp','qualification.py','verify_contract.py','test_qualification.py')],
 *['evidence/bootstrap/D1.06/'+x+'.py' for x in ('materialize-formal-candidate','logging-qualification-stage','logging-qualification-controls','formal-scope-wiring-index')]]
def record(path):
    data=path.read_bytes();return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)}
sources=[record(ROOT/n) for n in sorted(names)]
identity=hashlib.sha256(''.join(r['path']+'\t'+r['sha256']+'\n' for r in sources).encode()).hexdigest()
directories=['scope-mapping-red-7d3f06d6b6','scope-mapping-green-d6cd0a5211','logging-qualification-unwired-65a3bd2856',
 'logging-qualification-8d73c52c02','logging-qualification-a58636db31','logging-qualification-5382e06abf',
 'logging-qualification-5d3a4658f7','logging-qualification-controls-479cbc9ea6']
members={ROOT/n for n in names}
for folder in directories:
    members.update(p for p in (OUT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
build=ROOT/'build/d1.06-logqual-5d3a4658f7'
members.update(p for p in build.rglob('*') if p.is_file() and (p.suffix in ('.vcxproj','.cmake','.exe','.lib') or 'child-runs' in p.parts or p.name in ('logging-binding.json','LastTest.log')) and '__pycache__' not in p.parts)
rows=[record(p) for p in sorted(members)]
archive=OUT/'formal-scope-wiring-raw.zip'
if archive.exists():raise ValueError('do not overwrite archive')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(members):z.write(p,p.relative_to(ROOT).as_posix())
index={'status':'局部验证完成；候选正式清单仍阻断，非D1.06/G1 Passed','source_identity_algorithm':'sha256(UTF8(sorted(path TAB sha256 LF)))',
 'source_sha256':identity,'sources':sources,'evidence_directories':directories,'archive':record(archive),'members':rows,
 'actual_results':{'logging_debug_ctest':12,'tools_same_run':41,'formal_selection_guards':3,'formal_preload_exit':1,'new_ctest_missing_case_exit':8},
 'limits':['局部静态目标只编真实logging.cpp，不声明完整Runtime重建','未运行正式矩阵；footprint入口/预算仍缺','所有失败原目录保留，未迁移或删除']}
(OUT/'formal-scope-wiring-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'source_sha256':identity,'archive_sha256':index['archive']['sha256'],'members':len(rows)}))
