from pathlib import Path
import sys,json,importlib.util
root=Path.cwd();sys.path.insert(0,str(root))
from tools.evidence.process import execute
from tools.evidence.common import save_json,sha_file
out=Path(__file__).resolve().parent;src=out/'src';b=out/'build';src.mkdir()
inputs=['tools/dev/verify.py','tools/dev/current.py','tools/dev/README.md','tests/tools/dev/test_verify.py','tests/tools/dev/test_current.py','tests/manifests/d1.06-tools.expected.json','.gitignore']
result={'inputs':{p:sha_file(root/p) for p in inputs},'commands':[],'status':'Failed'}
spec=importlib.util.spec_from_file_location('verify_control',root/'tools/dev/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def run(label,argv):
    row=execute(argv,root,out/(label+'-stdout.log'),out/(label+'-stderr.log'),180)
    row['label']=label;row['raw']=[{'path':p.name,'sha256':sha_file(p)} for p in (out/(label+'-stdout.log'),out/(label+'-stderr.log'))]
    result['commands'].append(row);save_json(out/'checks.json',result)
    assert row['status']=='Exited' and row['exit_code']==0 and row['process_tree']['active_after']==0 and not row['process_tree']['terminated_owned_job'],label
(src/'main.cpp').write_text('int main(){ return 0; }\n')
(src/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.31.6)
project(PostBuildControl LANGUAGES CXX)
add_executable(probe main.cpp)
add_custom_command(TARGET probe POST_BUILD COMMAND "${REVIEW_PYTHON}" "${CMAKE_CURRENT_SOURCE_DIR}/discover.py" "${CMAKE_CURRENT_BINARY_DIR}/registered.txt" VERBATIM)
file(WRITE "${CMAKE_BINARY_DIR}/identity.txt" "generator=${CMAKE_GENERATOR}\\ncompiler=${CMAKE_CXX_COMPILER}\\ncompiler_version=${CMAKE_CXX_COMPILER_VERSION}\\ntoolset=${CMAKE_VS_PLATFORM_TOOLSET_VERSION}\\nsdk=${CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION}\\n")
''')
def script(value):
    (src/'discover.py').write_text('from pathlib import Path\nimport sys\nPath(sys.argv[1]).write_text('+repr(value)+')\n')
configure=['cmake','-S',str(src),'-B',str(b),'-G','Visual Studio 17 2022','-A','x64','-T','v143,version=14.44.35207','-DCMAKE_SYSTEM_VERSION=10.0.26100.0','-DCMAKE_TOOLCHAIN_FILE='+str(root/'cmake/LockedMSVC.cmake'),'-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded','-DREVIEW_PYTHON='+sys.executable]
bs={'build_dir':'original-tree','build':['cmake','--build','original-tree','--config','Debug','--parallel','2','--','/nr:false']}
try:
    script('old-registration');result['old_script_sha256']=sha_file(src/'discover.py')
    run('01-configure',configure);run('02-initial-build',v.build_command(bs,str(b),False))
    assert (b/'registered.txt').read_text()=='old-registration'
    script('new-registration');result['new_script_sha256']=sha_file(src/'discover.py')
    run('03-configure-after-script-change',configure)
    run('04-incremental-old-behavior',v.build_command(bs,str(b),False))
    result['incremental_registration']=(b/'registered.txt').read_text()
    assert result['incremental_registration']=='old-registration'
    selected=v.select(['tests/contract/native/discover.py']);result['discovery_selection']=selected
    run('05-clean-first-new-behavior',v.build_command(bs,str(b),selected['clean_build']))
    result['clean_registration']=(b/'registered.txt').read_text()
    assert result['clean_registration']=='new-registration'
    run('06-dev-unit-tests',[sys.executable,'-B','-X','utf8','-m','unittest','discover','-s','tests/tools/dev','-p','test_*.py','-v'])
    result['inputs_stable']=all(sha_file(root/p)==h for p,h in result['inputs'].items())
    result['toolchain_identity']=(b/'identity.txt').read_text()
    result['status']='ControlPassed'
except Exception as e:result['error']=str(e)
finally:save_json(out/'checks.json',result)
print(json.dumps({'status':result['status'],'error':result.get('error'),'inputs_stable':result.get('inputs_stable'),'out':str(out)},ensure_ascii=False))
raise SystemExit(0 if result['status']=='ControlPassed' else 1)
