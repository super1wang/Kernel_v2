from pathlib import Path
import sys
Path(sys.argv[1]).write_text('new-registration')
