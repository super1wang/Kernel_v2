from pathlib import Path
import sys,time,json
sys.path.insert(0,str(Path.cwd()))
from tools.evidence.summary import build_summary
from tools.evidence.common import sha_file
base=Path('evidence/a8049df35d74-028ca1c8afab')
rows=[]
for profile,run in [('win-msvc-debug','20260907T235925Z-a07bf46d5760'),('win-msvc-release','20260908T001937Z-799b5f40252d'),('win-msvc-asan','20260908T004118Z-0cdd375d90c8')]:
 p=base/profile/'D1.05'/run/'report.json'
 before={f.name:sha_file(f) for f in p.parent.iterdir() if f.is_file()}
 started=time.perf_counter();s=build_summary(p);elapsed=time.perf_counter()-started
 after={f.name:sha_file(f) for f in p.parent.iterdir() if f.is_file()}
 assert before==after
 rows.append({'report':p.as_posix(),'report_sha256':sha_file(p),'counts':s['counts'],'set_digests':s['set_digests'],'command_costs':s['command_costs'],'report_claims':s['report_claims'],'reference_count':len(s['references']),'review_archive':[r for r in s['references'] if r['role']=='review-archive'],'seconds_for_navigation_extraction':elapsed,'original_files_unchanged':True})
print(json.dumps(rows,ensure_ascii=False,indent=2))
