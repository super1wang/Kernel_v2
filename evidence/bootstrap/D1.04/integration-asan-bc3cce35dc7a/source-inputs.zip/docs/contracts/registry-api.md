# D1.03 注册API草案（待AI规格复核）

修订2：保持修订1已审规则，进一步明确add入口内复制及逐模块声明完成性；待增量AI复核。

本文件仅具体化D1.03，不代表公开SDK Runtime可用。命名空间为 `ock::runtime::registry`，内部头位于 `packages/runtime/registry/registry.hpp`；不安装该头。当前阶段的完整发布仅表示注册目录冻结，不表示Host Ready。

## 1. 基础类型与所有权

沿用 `contracts::Name/OperationKey/OperationVersion/DefinitionInput/DefinitionSnapshot/CppTypeToken/BindingPort` 与 `foundation::RegistryId/RegistryGeneration`。不新增另一套Operation身份、错误传输或Result。

`RegistryErrc` 为独立 `ock.registry` ErrorDomain，至少覆盖 InvalidManifest、DuplicateModule、MissingDependency、VersionMismatch、DependencyCycle、UndeclaredOperation、MissingOperation、DuplicateOperation、InvalidDefinition、MissingService、ServiceTypeMismatch、MissingProvider、ProviderMismatch、MissingExecutor、CapabilityMismatch、MissingResource、MissingConfiguration、UnsupportedSchema、CallbackException、BudgetExceeded、Frozen、InvalidIdentity。诊断 `RegistrationError { RegistryErrc code; optional<Name> module; optional<OperationKey> operation; }` 自有值，不保存异常what指针。

`BatchBudget { size_t modules=128, operations=4096, declarations=16384, text_bytes=1048576, diagnostics=128; }`，零限制拒绝创建；所有数量增加先做checked比较，不乘加溢出。诊断截断只限制记录数，单独的failed位一经置位不可复位；`diagnostics_truncated()`明确截断。

`ModuleDependency { Name name; OperationVersion version; }` 为精确模块版本需求；同一批次同模块name只允许一个版本。操作键允许同name不同version共存，精确key重复拒绝。

## 2. 提供项和声明

`ModuleManifest` 自有以下vector：模块 `Name name`、`OperationVersion version`、`dependencies`、`operations`（OperationKey）、`services`（Name）、`providers`（AtomicProviderKey）、`resources`（Name）、`required_configuration`（TypeIdentity）。还包括 `required_services`（ServiceRequirement）、`required_providers`（ProviderRequirement）、`required_resources`（ResourceRef）、`required_executors`（ExecutorRef）。精确结构如下：`ServiceRef {Name module; Name name;}`、`ProviderRef {Name module; AtomicProviderKey key;}`、`ResourceRef {Name module; Name name;}`、`ExecutorRef {Name module; Name name;}`；`ServiceRequirement {ServiceRef ref; CppTypeToken type;}`、`ProviderRequirement {ProviderRef ref; CppTypeToken type;}`。每个ref按(module,name/key)精确匹配，重复需求拒绝；不同模块同名提供项不冲突，也不按类型猜选。跨模块提供者必须为直接声明依赖且在对应required集合中，不能越过DAG偷取全局服务。本模块自身提供项也须经显式ref选择，但不要求自依赖。

`ServiceBinding::make<T>(Name, shared_ptr<T>)` 返回Result；私有构造保存实际CppTypeToken和owner，拒绝空owner。T为非const对象类型。模块输入的同名服务必须恰好与manifest提供集合一致，不允许声明无实现或实现未声明。

`ProviderBinding::make<P>(shared_ptr<contracts::AtomicProviderPort<P>>)` 由 `ProviderContract<P>::key()` 和 `CppTypeToken::of<P>()`产生匹配信息，拒绝空owner，不接收可随意自报的type token/void owner组合。

`ResourceBinding {Name name; shared_ptr<contracts::ResourceLease> owner;}` 表示注册阶段已装配资源槽的寿命，不是调用授权；必须非空且与manifest一致。调用时租约与授权仍由后续管线取得，不能把该声明当许可。

`ConfigurationBinding::make<T>(const T& value)` 仅接受ContractValue<T>且显式定义 `ConfigurationSnapshot<T>::freeze(const T&) -> Result<T>` 的类型。没有默认复制回退；freeze合同要求结果及全部可达配置值与输入的可变别名断开，保留语义值。冻结输出再经TypeContract<T>::validate，随后移入内部const owner并记录TypeIdentity。冻结器属于受审可信native适配，不宣称模板可证明任意C++图深不可变；对应夹具必须以包含shared_ptr<mutable>成员的类型实际验证输入后改/销毁不影响快照，无freeze策略编译拒绝。该配置接口不对外返回可变T引用。仅支持typed native配置，本包不解析TOML/JSON。声明的TypeIdentity必须全部有精确匹配，错误/遗漏拒绝。

`ExecutorBinding {Name name; Name affinity; bool async_dispatch; bool external_wait; shared_ptr<contracts::ExecutorPort> owner;}` 由组合根提供，必须有真实非空端口；本包验证静态装配要求而不启动线程或调用submit。不能把该检查称作D3执行器Conformance。

`ModuleInput { ModuleManifest manifest; vector<ServiceBinding> services; vector<ProviderBinding> providers; vector<ResourceBinding> resources; vector<ConfigurationBinding> configurations; vector<ExecutorBinding> executors; std::function<void(Registrar&)> register_operations; }`。ModuleManifest另有 `executors`（Name）声明提供的executor集合，必须与实际提供项恰好一致；各提供集合重复key及未声明/无实现均拒绝。注册钩子复制其函数对象；其显式借用捕获由可信模块负责保持至同步钩子执行结束，不能宣称可以深拷贝任意C++闭包引用。manifest、提供项vector及配置快照不借用调用者内存。add接收const引用后在入口异常保护中逐成员复制到独立容器；即使调用者传std::move并保留原vector元素地址，后续修改也不能改变候选声明或owner槽。共享owner控制块允许共享，但保存owner的元素本身必须独立。注册后Catalog保有被绑定服务/provider/executor/resource owner。

## 3. 批次状态

```cpp
class RegistrationBatch final {
public:
  static Result<std::unique_ptr<RegistrationBatch>> create(BatchBudget);
  Result<void> add(const ModuleInput&); // 在入口异常保护内复制全部容器
  Result<std::shared_ptr<const Catalog>> publish();
  std::span<const RegistrationError> errors() const noexcept;
  bool failed() const noexcept;
  bool diagnostics_truncated() const noexcept;
};
```

批次不可复制/移动。仅组合根持有RegistrationBatch；模块钩子仅得到Registrar。状态为Collecting→Validating→Published或Failed，所有失败为终结状态；任何add、Registrar入口、publish检测失败时必须先以不分配操作设置failed位/Failed状态，再构造或追加诊断。上述入口的异常保护捕获进入入口后产生的异常（外部实参表达式求值失败尚未调用入口，批次不可能观察；add的容器复制明确位于入口内），先置failed，再按异常类别记录或重新抛出；模块catch bad_alloc后也不可挽回该批。诊断记录自身失败不覆盖原失败，不要求在内存不足时再成功分配诊断。成功目录只在全部验证/钩子/后验证成功后返回。publish重入或二次调用拒绝。add在非Collecting拒绝，不改变已发布目录；失败后不能清空错误重新开始，需创建新批次。

publish顺序：验证预算和精确manifest集合（包括跨模块重复OperationKey声明，必须在钩子前拒绝）→DAG拓扑→逐模块验证提供项及依赖可用性→执行钩子、记录所有错误/异常→核对每模块实际与声明操作集合（实际注册记录绑定所属模块，只能用本模块成功项满足声明，不能扫描全目录借用另一模块条目）→构建完整冷/热候选→一次返回const Catalog。错误可继续收集但不得继续调用具有未满足依赖的模块钩子；全部批次仍失败，不存在部分发布。任何异常路径无部分可见状态，捕获模块异常记CallbackException；分配异常不伪造成业务成功，可传播但候选由RAII释放。

诊断span仅在批次稳定且存活时可用，是同步查看接口。调用者不得并发修改批次；冻结Catalog允许并发只读。批次不保存或公开之前发布目录的可变指针。

## 4. Registrar窄入口

`OperationOptions { optional<ServiceRef> read_service; optional<ProviderRef> provider; ExecutorRef executor; vector<ResourceRef> resources; bool requires_dynamic_schema=false; }` 是操作声明的静态资源需求，必须按完整ref绑定当前模块/已声明依赖的资源；重复ref拒绝，不按Name单独查找。不表示执行授权。options.executor.name必须与DefinitionInput.execution.executor精确一致，模块选择来自options.executor.module且满足依赖/required_executors；affinity及能力以实际精确选中提供项核对。requires_dynamic_schema=true在本阶段记录UnsupportedSchema，直到后续真实Schema能力实施才可另案扩展。

Registrar由批次私有构造，禁止复制/移动，寿命仅限同步钩子。所有注册入口返回Result<void>并由批次内部粘性记录错误：

- `read<A,R,Reader>(Result<R>(*)(const A&,WorkContext&,ReadServices<Reader>&), const DefinitionInput&, const OperationOptions&)`。
- `compute<A,R>(Result<R>(*)(const A&,WorkContext&), const DefinitionInput&, const OperationOptions&)`。
- `state_edit<A,R,P>(Result<R>(*)(const A&,EditView<P>&,WorkContext&), const DefinitionInput&, const OperationOptions&)`。
- `external_effect<A,R>(EffectReport<R>(*)(const A&,EffectContext&), const DefinitionInput&, const OperationOptions&)`。
- `lifecycle<A,R>(TransitionReport<R>(*)(const A&,TransitionView&), const DefinitionInput&, const OperationOptions&)`。
- `candidate_read<A,R,Reader,P>(Result<R>(*)(const A&,WorkContext&,ReadServices<Reader>&), Result<R>(*)(const A&,const typename P::CandidateReadPort&,WorkContext&), const DefinitionInput&, const OperationOptions&)`：内部构建Read definition再调用candidate转换，双方类型与ProviderContract匹配才注册。
- `service<T>(const Name& provider_module,const Name& service_name)` 返回Result<shared_ptr<T>>；仅当前模块声明所需服务可查找，结果类型与真实提供者相同且保有owner。不提供全局遍历/resolve-anything。

以上A/R约束沿用ContractValue/ContractResult；不能提供接收任意DefinitionSnapshot与void handler的公共“万能注册”入口。非法签名编译拒绝；空fn、工厂返回错误、未声明key、重复key、缺执行器/资源/provider都记入同一批次。DefinitionInput由D1.02工厂复制，调用者后续修改不能改变目录。

Read及candidate必须给出options.read_service，用完整ref选中唯一服务且Reader类型精确匹配；另一个同类型服务不会被自动替代。compute无需只读服务且禁止read_service/provider字段；StateEdit要求provider且禁止read_service；Effect/Lifecycle禁止两字段。StateEdit和candidate必须给出options.provider并精确匹配已绑定真实provider的module/key和P类型；Read不带candidate时禁止provider。执行要求的executor/affinity精确匹配，并检查async/external_wait需求；Atomic仍使用D1.02的约束拒绝等待/异步。每个成功条目保存其所需依赖owner，后续调用无需动态定位。

Handler存入内部私有类型擦除owner，记录真实函数指针类型。Registrar不返回handler或内部槽；Catalog无handler获取方法；D1.05另行增加只给内部Invocation的受控适配。不能用测试专用public getter破坏本包边界。

## 5. Catalog与冷/热分离

```cpp
class Catalog final : public contracts::BindingPort {
public:
  RegistryId identity() const noexcept override;
  RegistryGeneration generation() const noexcept override;
  std::size_t size() const noexcept override;
  Result<OperationHandle> find(const OperationKey&) const override;
  Result<std::shared_ptr<const DefinitionSnapshot>> describe(std::uint32_t) const override;
};
```

Catalog只有批次可构造。identity来自当前进程内部不复用的单调64位发行序号编码为Tagged128，序号耗尽拒绝，不回绕；发行器不对模块开放。generation为该不可变目录内部有效非零世代，不提供更新接口；Native目录身份不作为可持久化跨进程票据。不同Catalog不可接受相同RegistryId，即使操作文本完全相同。BoundOperation按既有resolve_slot检查身份/世代/范围后访问describe；测试旧世代/伪槽使用真实Catalog身份与伪handle对照，不为测试暴露可变世代。

内部 `HotEntry` 只保存shape、私有handler owner与CppTypeToken、已绑定的服务/provider/executor/resource owner及执行标量。不得保存Docs、DefinitionSnapshot或指向冷描述的快捷指针。完整DefinitionSnapshot与精确key索引在独立cold结构；Catalog同时拥有两组存储，但热槽不可遍历冷Docs。结构检查与源依赖检查验证这一点；绑定/describe不是Invoke热路径，本包不宣称已测零分配Invoke。

describe返回不可变自有snapshot；目录销毁后已取得snapshot仍有效。BoundOperation保有Catalog，Catalog保有依赖，因此批次/输入销毁后绑定仍可校验。没有直接可写的冷热vector引用。

## 6. 验证和审核

25项新增测试名称及对应反例见D1.03计划。service_binding增加同Reader不同模块选择对照；provider_binding/execution_capabilities增加同名跨模块资源/provider/executor明确选择与越依赖拒绝；manifest_owned_budget覆盖shared_ptr配置深冻结、无冻结器编译拒绝及move前保留vector元素别名的对照；declared_operations_complete/exact_operation_versions覆盖另一模块只声明同key而不注册的拒绝；ignored_errors_sticky/error_budget_sticky覆盖诊断分配失败被模块捕获后仍不发布。首轮前须冻结本API和expected，补足本草案被审核发现的缺口。实际实现与反例均要独立AI规格/代码复核。整包Passed只能来自固定完整三配置、9项CHECK、原始owned Job/编译正负例/源码与Git一致性；尚无任何D1.03实际实现通过记录。
